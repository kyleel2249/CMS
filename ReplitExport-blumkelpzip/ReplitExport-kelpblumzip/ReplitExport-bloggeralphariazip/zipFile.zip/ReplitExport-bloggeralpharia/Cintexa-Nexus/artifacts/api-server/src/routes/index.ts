import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import contactsRouter from "./contacts";
import companiesRouter from "./companies";
import leadsRouter from "./leads";
import dealsRouter from "./deals";
import ticketsRouter from "./tickets";
import campaignsRouter from "./campaigns";
import invoicesRouter from "./invoices";
import projectsRouter from "./projects";
import tasksRouter from "./tasks";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(contactsRouter);
router.use(companiesRouter);
router.use(leadsRouter);
router.use(dealsRouter);
router.use(ticketsRouter);
router.use(campaignsRouter);
router.use(invoicesRouter);
router.use(projectsRouter);
router.use(tasksRouter);
router.use(aiRouter);

export default router;

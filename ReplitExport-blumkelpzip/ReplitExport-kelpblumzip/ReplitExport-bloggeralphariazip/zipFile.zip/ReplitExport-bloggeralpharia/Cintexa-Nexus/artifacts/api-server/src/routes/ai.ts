import { Router } from "express";

const router = Router();

const AI_RESPONSES = [
  "Based on your CRM data, I've identified 3 high-value leads in the proposal stage that haven't been contacted in over 5 days. I recommend scheduling follow-ups today.",
  "Your Q3 pipeline shows $2.4M in active deals with a 67% weighted probability. The negotiation stage has the highest drop-off — consider offering a limited-time incentive.",
  "Support ticket volume is up 18% this week, primarily around billing questions. I recommend creating a self-service FAQ to reduce first-contact resolution time.",
  "Email campaign 'Q4 Product Launch' achieved a 34% open rate — 2x industry average. The segment responding best is enterprises with 100-500 employees.",
  "Cash flow forecast: you're projected to be positive through Q1. Two invoices totaling $47,000 are overdue — I can draft follow-up emails if you'd like.",
  "I've analyzed your top 10 closed deals this quarter. The common factor: deals that closed within 21 days had at least 3 touchpoints in the first week.",
  "Your team's average ticket resolution time is 4.2 hours — top quartile for your industry. Sarah leads with 98% satisfaction and 2.1h average.",
];

router.post("/ai/chat", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "message is required" });

    // Simulate AI processing delay
    await new Promise((r) => setTimeout(r, 600));

    const reply =
      AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];

    const suggestions = [
      "Show me this week's pipeline",
      "Which deals need attention?",
      "Generate a board summary",
      "What's my revenue forecast?",
    ];

    res.json({ reply, suggestions });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "AI service unavailable" });
  }
});

router.get("/ai/morning-brief", async (req, res) => {
  try {
    const today = new Date().toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    res.json({
      date: today,
      headline: "Strong pipeline momentum — 3 deals expected to close this week",
      insights: [
        "Pipeline value increased 14% week-over-week driven by 4 new enterprise deals",
        "Support team resolved 94% of tickets within SLA — exceeding the 90% target",
        "Email campaign conversion rate up 8% after subject line optimization",
        "2 invoices totaling $63,500 are overdue — follow-up recommended today",
        "Highest lead quality source this month: referrals (avg score 81)",
      ],
      priorities: [
        "Follow up on Meridian Corp proposal — last contact 6 days ago",
        "Review Q4 marketing budget allocation before Friday",
        "Approve 3 pending project milestones blocking the dev team",
        "Send overdue payment reminders to Vertex Solutions and Northgate Inc",
      ],
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to generate brief" });
  }
});

export default router;

import { Router } from "express";
import { db, leadsTable, activityTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

function toResponse(l: typeof leadsTable.$inferSelect) {
  return {
    id: l.id,
    name: l.name,
    email: l.email,
    phone: l.phone ?? null,
    company: l.company ?? null,
    source: l.source,
    status: l.status,
    score: l.score,
    notes: l.notes ?? null,
    createdAt: l.createdAt.toISOString(),
  };
}

router.get("/leads", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const limit = Number(req.query.limit ?? 50);
    let query = db.select().from(leadsTable);
    if (status) {
      query = query.where(eq(leadsTable.status, status)) as typeof query;
    }
    const rows = await query.orderBy(desc(leadsTable.createdAt)).limit(limit);
    res.json(rows.map(toResponse));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch leads" });
  }
});

router.post("/leads", async (req, res) => {
  try {
    const [row] = await db.insert(leadsTable).values(req.body).returning();
    await db.insert(activityTable).values({
      type: "lead",
      title: "New lead captured",
      description: `${row.name} from ${row.company ?? row.source} — score ${row.score}`,
    });
    res.status(201).json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create lead" });
  }
});

router.patch("/leads/:id", async (req, res) => {
  try {
    const [row] = await db
      .update(leadsTable)
      .set(req.body)
      .where(eq(leadsTable.id, Number(req.params.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update lead" });
  }
});

router.delete("/leads/:id", async (req, res) => {
  try {
    await db.delete(leadsTable).where(eq(leadsTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete lead" });
  }
});

export default router;

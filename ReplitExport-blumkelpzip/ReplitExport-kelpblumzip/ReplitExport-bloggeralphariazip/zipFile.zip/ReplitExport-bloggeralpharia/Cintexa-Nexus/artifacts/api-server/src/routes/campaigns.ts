import { Router } from "express";
import { db, campaignsTable, activityTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

function toResponse(c: typeof campaignsTable.$inferSelect) {
  return {
    id: c.id,
    name: c.name,
    type: c.type,
    status: c.status,
    audienceSize: c.audienceSize,
    sent: c.sent ?? null,
    opened: c.opened ?? null,
    clicked: c.clicked ?? null,
    converted: c.converted ?? null,
    scheduledAt: c.scheduledAt ?? null,
    createdAt: c.createdAt.toISOString(),
  };
}

router.get("/campaigns", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const limit = Number(req.query.limit ?? 50);
    let query = db.select().from(campaignsTable);
    if (status) {
      query = query.where(eq(campaignsTable.status, status)) as typeof query;
    }
    const rows = await query.orderBy(desc(campaignsTable.createdAt)).limit(limit);
    res.json(rows.map(toResponse));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch campaigns" });
  }
});

router.post("/campaigns", async (req, res) => {
  try {
    const [row] = await db.insert(campaignsTable).values(req.body).returning();
    await db.insert(activityTable).values({
      type: "campaign",
      title: "Campaign created",
      description: `${row.type.toUpperCase()} campaign "${row.name}" — ${row.audienceSize.toLocaleString()} recipients`,
    });
    res.status(201).json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create campaign" });
  }
});

router.patch("/campaigns/:id", async (req, res) => {
  try {
    const [row] = await db
      .update(campaignsTable)
      .set(req.body)
      .where(eq(campaignsTable.id, Number(req.params.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update campaign" });
  }
});

router.delete("/campaigns/:id", async (req, res) => {
  try {
    await db.delete(campaignsTable).where(eq(campaignsTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete campaign" });
  }
});

export default router;

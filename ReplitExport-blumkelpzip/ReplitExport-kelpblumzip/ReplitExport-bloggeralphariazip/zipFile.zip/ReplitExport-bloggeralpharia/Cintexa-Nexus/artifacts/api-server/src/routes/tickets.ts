import { Router } from "express";
import { db, ticketsTable, activityTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

function toResponse(t: typeof ticketsTable.$inferSelect) {
  return {
    id: t.id,
    subject: t.subject,
    description: t.description ?? null,
    status: t.status,
    priority: t.priority,
    channel: t.channel,
    contactName: t.contactName,
    assignedTo: t.assignedTo ?? null,
    tags: t.tags ? t.tags.split(",").filter(Boolean) : [],
    createdAt: t.createdAt.toISOString(),
  };
}

router.get("/tickets", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const priority = req.query.priority as string | undefined;
    const limit = Number(req.query.limit ?? 50);

    const conditions = [];
    if (status) conditions.push(eq(ticketsTable.status, status));
    if (priority) conditions.push(eq(ticketsTable.priority, priority));

    const rows = await db
      .select()
      .from(ticketsTable)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(ticketsTable.createdAt))
      .limit(limit);
    res.json(rows.map(toResponse));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch tickets" });
  }
});

router.post("/tickets", async (req, res) => {
  try {
    const body = { ...req.body };
    if (Array.isArray(body.tags)) body.tags = body.tags.join(",");
    const [row] = await db.insert(ticketsTable).values(body).returning();
    await db.insert(activityTable).values({
      type: "ticket",
      title: "Support ticket opened",
      description: `${row.priority.toUpperCase()} — ${row.subject}`,
    });
    res.status(201).json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create ticket" });
  }
});

router.patch("/tickets/:id", async (req, res) => {
  try {
    const body = { ...req.body };
    if (Array.isArray(body.tags)) body.tags = body.tags.join(",");
    const [row] = await db
      .update(ticketsTable)
      .set(body)
      .where(eq(ticketsTable.id, Number(req.params.id)))
      .returning();
    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(toResponse(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update ticket" });
  }
});

router.delete("/tickets/:id", async (req, res) => {
  try {
    await db.delete(ticketsTable).where(eq(ticketsTable.id, Number(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete ticket" });
  }
});

export default router;
